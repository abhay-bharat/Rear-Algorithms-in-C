#include<stdio.h>
#include<stdlib.h>
#include "assignment_4.h"
// create a file with the filename and initialize the header with tree_t structure
// if the file already exists, just return the file ptr
FILE* init_tree(const char* filename)
{
  //creating a file
  FILE* fp;
  fp = fopen(filename, "r+");//opens file if already exists
  if(fp == NULL){
    fp = fopen(filename, "w"); //creates file in case file doesn't exists.
  	//initializing the tree
  	tree_t t;
  	t.free_head = -1; //pointing to null
  	t.root = -1; //Pointing to null
  	fseek(fp, 0, SEEK_SET); //setting file pointer to point to beginning of file
  	fwrite(&t, sizeof(tree_t), 1, fp);
  	//Closing and opening file again so that it opens in both read and write mode
	fclose(fp);
	fp = fopen(filename, "r+");
	}
  return fp;
}

// closes the file pointed by fp
void close_tree(FILE *fp)
{
  fclose(fp);
}

//Function to recursively call inorder 
void recursive_inorder(FILE* fp, node_t* node)
{
  node_t left_node; //node holding left child
  node_t right_node; //node holding right child
  if(node->left_offset != -1){
	fseek(fp, node->left_offset, SEEK_SET);
  	fread(&left_node, sizeof(node_t), 1, fp);
    recursive_inorder(fp,&left_node);
  }

  printf("%d ",node->key);

  if(node->right_offset != -1){
	fseek(fp,node->right_offset, SEEK_SET);
  	fread(&right_node, sizeof(node_t), 1, fp);
    recursive_inorder(fp,&right_node);
  }
}

// Space separated keys displayed in inorder 
void display_inorder(FILE *fp)
{
  tree_t t;
  node_t n;
  fseek(fp, 0, SEEK_SET);
  fread(&t, sizeof(tree_t), 1, fp);
  //root -1 indicates that tree is empty
  if(t.root != -1){
  fseek(fp, t.root, SEEK_SET);
  fread(&n, sizeof(node_t), 1, fp);
  recursive_inorder(fp, &n); //To recursive call of the inorder function, starting with rootnode.
  }
  printf("\n");
}

void recursive_preorder(FILE* fp, node_t* node)
{
  node_t left_node;
  node_t right_node;
  
  printf("%d ",node->key);  
 if(node->left_offset != -1){
	fseek(fp, node->left_offset, SEEK_SET);
  	fread(&left_node, sizeof(node_t), 1, fp);
    recursive_preorder(fp,&left_node);
  }
  if(node->right_offset != -1){
	fseek(fp,node->right_offset, SEEK_SET);
  	fread(&right_node, sizeof(node_t), 1, fp);
    recursive_preorder(fp,&right_node);
  }
}
// Space separated keys displayed in preorder
void display_preorder(FILE *fp)
{
  tree_t t;
  node_t n;
  fseek(fp, 0, SEEK_SET);
  fread(&t, sizeof(tree_t), 1, fp);
  if(t.root != -1){
  fseek(fp, t.root, SEEK_SET);
  fread(&n, sizeof(node_t), 1, fp);
  recursive_preorder(fp, &n); //To recursive call of the preorder function, starting with rootnode.
  }
  printf("\n");
}

// inserts the key into the tree in the file
// if the key already exists it just returns
void insert_key(int key, FILE *fp)
{
  int pos; //holds the offset in file where node is to be placed in file
  node_t temp; //to hold the member values of the node to be inserted
  node_t free_node; //holds the node if taken from the free places in between the file(holes created when node deleted)
  tree_t t;
  fseek(fp, 0, SEEK_SET);
  fread(&t, sizeof(tree_t), 1, fp);
  //If no free nodes then move to the end till where file is currently written
  if(t.free_head == -1)
  {
  	fseek(fp, 0, SEEK_END);
  	pos = ftell(fp);
  }
  else  //if free nodes exist
  {
  	pos = t.free_head;
	fseek(fp, pos, SEEK_SET);
	fread(&temp, sizeof(node_t), 1, fp);
	free_node = temp; //free_node to be used only when the new node was added at the existing free position(not in the case if duplicate values are tried to insert)
  }
   //initialize node
  temp.key = key;
  temp.left_offset = -1;
  temp.right_offset = -1;
  //If tree is empty
  if(t.root == -1)
  {

  	t.root = pos;
  	fseek(fp, pos, SEEK_SET);
  	fwrite(&temp, sizeof(node_t), 1, fp); fseek(fp, 0, SEEK_SET);
  	fwrite(&t, sizeof(tree_t), 1, fp);
  }
  else{           //else iteratively traverse to the apt position where node is to be virtual inserted so as to follow bst constrains
    int flag;
    int prev = -1;
    int pres = t.root;
    node_t pres_node; //holds present node 
    node_t prev_node; //holds previous node
    while(pres != -1) //While we don't reach the position
    {
      prev = pres;
      fseek(fp, pres, SEEK_SET);
      fread(&pres_node, sizeof(node_t), 1, fp);
      if(pres_node.key > key){
        flag = 0; //flag 0 indicates node to be inserted as left child of previous node
        pres = pres_node.left_offset;
      }
      else if(pres_node.key < key){
        flag = 1;  //flag 1 indicates node to be inserted as right child of previous node
        pres = pres_node.right_offset;
      }
      else if(pres_node.key == key) //if duplicate key just return without doing anything
        return;
    }
    fseek(fp, prev, SEEK_SET);
    fread(&prev_node, sizeof(node_t), 1, fp); //reading previous node
    if(flag)
    {
    	prev_node.right_offset = pos;
    }
    else{
    	prev_node.left_offset = pos;
    }
    fseek(fp, prev, SEEK_SET);
    fwrite(&prev_node, sizeof(node_t), 1, fp);
    fseek(fp, pos, SEEK_SET);
    fwrite(&temp, sizeof(node_t), 1,fp);
   }
  //free_head changes only if free_node is utilised
  if(t.free_head != -1){
	t.free_head = free_node.right_offset;
  }
  fseek(fp, 0, SEEK_SET);
  fwrite(&t, sizeof(tree_t), 1, fp);
}

//Function to implement delete recursively
int recursive_delete(FILE *fp, int key, int offset, tree_t *t)
{
	node_t temp_node;
	node_t node;
	if(offset != - 1) 
	{
		fseek(fp, offset, SEEK_SET);
		fread(&node, sizeof(node_t), 1, fp);
	}
	if(offset == -1) //if reached the end without finding key to be deleted then just return the offset 
		return offset;
	else if(node.key > key)
	{
		node.left_offset = recursive_delete(fp,key,node.left_offset, t);
		//after returning the offset its left_offset is updated and written into the file
		fseek(fp, offset, SEEK_SET);
		fwrite(&node, sizeof(node_t), 1, fp);
	}
	else if(node.key < key)
	{
		node.right_offset = recursive_delete(fp,key,node.right_offset, t);
		fseek(fp, offset, SEEK_SET);
		fwrite(&node, sizeof(node_t), 1, fp);
	}
	else  //enters this block when key to be deleted is found 
	{
		if(node.left_offset == -1) //if has only right subtree 
		{
			int temp1 = node.right_offset; //temp1 holding the right offset value which is returned 
			node.right_offset = t->free_head; //Inserting the deleted node at beginning of free node list
			node.left_offset = -1;
			fseek(fp, offset, SEEK_SET);
			fwrite(&node, sizeof(node_t), 1, fp);
			t->free_head = offset;
			return temp1;
		}
		else if(node.right_offset == -1)  //if has only left subtree
		{
			int temp1 = node.left_offset;
			node.right_offset = t->free_head;
			node.left_offset = -1;
			fseek(fp, offset, SEEK_SET);
			fwrite(&node, sizeof(node_t), 1, fp);
			
			t->free_head = offset;
			return temp1;
		}
		else  //when has both left and right subtree 
		{	  //logic used is to replace the node.key to be deleted with the inorder successor value
			int temp;
			temp = node.right_offset; //pointing to right subtree
			fseek(fp, temp, SEEK_SET);
			fread(&temp_node, sizeof(node_t), 1, fp);
			
			while(temp_node.left_offset != -1)
			{
				temp = temp_node.left_offset;
				fseek(fp, temp, SEEK_SET);
				fread(&temp_node, sizeof(node_t), 1, fp);
			}
			node.key = temp_node.key; //replacing key as per logic
			fseek(fp, offset, SEEK_SET);
			fwrite(&node, sizeof(node_t), 1, fp);
			//now call delete recursively on the replaced node in the right subtree
			node.right_offset = recursive_delete(fp, temp_node.key, node.right_offset, t);
			fseek(fp, offset, SEEK_SET);
			fwrite(&node, sizeof(node_t), 1, fp);
		}
	}
	return offset;
}
// deletes the key from the tree in the file
// if key doesn't exist it just returns
void delete_key(int key, FILE *fp)
{
	tree_t *t = (tree_t*)malloc(sizeof(tree_t));
	node_t node;
	fseek(fp, 0, SEEK_SET);
	fread(t, sizeof(tree_t), 1, fp);
	if(t->root != -1){
		t->root = recursive_delete(fp,key, t->root, t);
		fseek(fp, 0, SEEK_SET);
		fwrite(t, sizeof(tree_t), 1, fp);
	}
	free(t);
}
